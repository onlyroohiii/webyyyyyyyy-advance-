# ADVANCE Coaching Academy — website starter

A responsive, static website prototype for ADVANCE Coaching Academy. It uses plain HTML, CSS, and JavaScript, so there is no build step or package installation required.

## Preview locally
1. Extract the ZIP.
2. Open `index.html` in a browser.
3. For a more realistic local server preview, use VS Code's Live Server extension or run `python -m http.server 8000` in this folder, then visit `http://localhost:8000`.

## Deploy to Vercel
1. Create a GitHub repository and upload `index.html`, `style.css`, `script.js`, and this README.
2. In Vercel, import the GitHub repository.
3. Framework preset: **Other**. Build command: leave blank. Output directory: `.` (or leave default if Vercel detects static content).
4. Deploy and test the generated preview URL.

## Before public launch — replace these placeholders
- Replace `91XXXXXXXXXX` in `script.js` with the official academy WhatsApp number (country code + number, digits only).
- Confirm the exact street address and Google Maps pin.
- Confirm course offerings, subjects, fees, batch timings, days, and opening hours.
- Replace teacher placeholders with approved names, photos, qualifications, and introductions.
- Replace sample classroom images with actual academy photos.
- Add real, approved student achievements and testimonials. Do not publish student names/photos/results without permission.
- Add the academy's real video/reel URLs and official social media links.
- Add a privacy notice suitable for the enquiry form and the academy's practices.

## Important notes
- The admission form does not store submissions. It prepares a WhatsApp message for the visitor to review and send.
- The current Google Map is a search for the approximate area, not a verified exact academy pin.
- Remote images and Google Fonts need an internet connection.
- Confirm Vercel plan terms for a business website before production use.
