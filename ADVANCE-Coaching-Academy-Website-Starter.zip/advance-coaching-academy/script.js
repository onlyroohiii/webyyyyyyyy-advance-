const menuToggle = document.querySelector('.menu-toggle');
const mainNav = document.querySelector('.main-nav');

menuToggle?.addEventListener('click', () => {
  const isOpen = mainNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
});

mainNav?.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    mainNav.classList.remove('open');
    menuToggle?.setAttribute('aria-expanded', 'false');
    menuToggle?.setAttribute('aria-label', 'Open navigation');
  });
});

document.querySelectorAll('.main-nav a[href^="#"]').forEach((link) => {
  link.addEventListener('click', () => {
    document.querySelectorAll('.main-nav a').forEach((item) => item.classList.remove('active'));
    link.classList.add('active');
  });
});

const form = document.getElementById('enquiry-form');
const status = document.getElementById('form-status');

// IMPORTANT: Replace this placeholder with the academy's official WhatsApp number.
// Use country code + number only, without spaces or punctuation, e.g. 91XXXXXXXXXX.
const ACADEMY_WHATSAPP_NUMBER = '91XXXXXXXXXX';

form?.addEventListener('submit', (event) => {
  event.preventDefault();
  if (!form.reportValidity()) return;

  if (ACADEMY_WHATSAPP_NUMBER.includes('X')) {
    status.textContent = 'The enquiry form is ready, but the academy WhatsApp number must be added before it can open a message. Please contact the academy directly for now.';
    status.style.color = '#8a5a22';
    return;
  }

  const data = new FormData(form);
  const message = [
    'Hello ADVANCE Coaching Academy, I would like to enquire about admissions.',
    '',
    `Student name: ${data.get('student')}`,
    `Parent / guardian: ${data.get('guardian')}`,
    `Contact number: ${data.get('phone')}`,
    `Class / exam: ${data.get('level')}`,
    `Preferred course / question: ${data.get('message') || 'Not specified'}`,
    '',
    'Please share the relevant course details. Thank you.'
  ].join('\n');

  const url = `https://wa.me/${ACADEMY_WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank', 'noopener,noreferrer');
  status.textContent = 'WhatsApp is opening with your enquiry. Review the message and press Send to submit it.';
  status.style.color = '#315e45';
});

document.getElementById('year').textContent = new Date().getFullYear();
